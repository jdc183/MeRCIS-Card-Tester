import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 
import garciadelcastillo.dashedlines.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ui extends PApplet {




GUI frame1;  //GUI container object for all the elements
Plot scope;  //Graph of the transfer characteristics
Button playButton;  //button to advance test
Button refreshButt; //Button to refresh the
Button resetButton; //Clears the scope buffer and stops test
Dropdown portsDropdown;  //Dropdown to select COM port
TextEntry rSenseEntry;  //
TextEntry stepEntry;
TextEntry bufferEntry;
//String portName;
Serial testerPort;  //The serial port object we yuse here
String in;
String[] portList;
char readin;
float dacVolts;
float adcVolts;
float stepVoltage;
float dir;
float rSense;
int bufferSize;
boolean go;
//color bg1;
//color bg2;
//color bg3;
//color fg1;
//color fg2;
//color fg3;
boolean mouseOverNothing;
public int previousMouseX, previousMouseY;
int timeOfLastClick;
int bufferMax;
PFont baseFont;
public PApplet papple;

public void setup() {  //This method is called once at startup
    //Nice resolution for small screens, could easily be changed
  //String[] fontList = PFont.list();
  //printArray(fontList);
  
  //baseFont = createFont("Monospace.plain",18);
  //textFont(baseFont);
  
  papple = this;
  
  prepareExitHandler();
  
  //elements = new ArrayList<Element>();//Arraylist to contain gui elements
  frame1 = new GUI();
  
  //This button advances the test
  playButton = new Button(frame1, 10,10,70,26,"\u25ba",new Runnable(){public void run(){playButtonCallback();}});
  frame1.add(playButton);
  
  //This is the plot of the amplifier transfer characteristics
  scope = new Plot(frame1, 10,45,760,420,"Scope","Input Voltage (V)","Output Current (mA)");//,4.0,-0.1,4.0,-0.1);
  frame1.add(scope);
  
  resetButton = new Button(frame1, 90,10,50,26,"RST",new Runnable(){public void run(){reset();}});
  frame1.add(resetButton);
  
  //This is a dropdown for selecting the serial port
  portsDropdown = new Dropdown(frame1, 570,10,200,26,"No UART detected", new Runnable(){public void run(){changeSerial();}});
  frame1.add(portsDropdown);
  
  //This button refreshes the serial port list
  refreshButt = new Button(frame1, 744,10,26,26,"\u21bb",new Runnable(){public void run(){refreshPorts();}});
  frame1.add(refreshButt);
  
  rSenseEntry = new TextEntry(frame1, 220,10,46,26,"rSense",new Runnable(){public void run(){changerSense();}});
  frame1.add(rSenseEntry);
  rSense = 3.3f/400*1000;
  rSenseEntry.setValue(str(rSense));
  rSenseEntry.setStep(0.01f);
  
  bufferEntry = new TextEntry(frame1, 500,10,56,26,"buffer",new Runnable(){public void run(){changeBufferMax();}});
  frame1.add(bufferEntry);
  bufferMax = 1320;
  bufferEntry.setValue(str(bufferMax));
  bufferEntry.setStep(1.0f);
  
  stepEntry = new TextEntry(frame1, 356,10,46,26,"step",new Runnable(){public void run(){changeStepVoltage();}});
  frame1.add(stepEntry);
  stepVoltage = 0.01f;
  stepEntry.setValue(str(stepVoltage));
  stepEntry.setStep(0.01f);
  
  //Add the initially detected ports to the dropdown
  portList = Serial.list();
  for (String p : portList){
    portsDropdown.add(p);
  }
  
  if (portList.length > 0) portsDropdown.setSelected(0);
 
  //These parameters are used to scale the test input/output
  adcVolts = 0.0f; dacVolts = 0.0f; dir = stepVoltage;
  //Not used yet
  go = false;
  
  
  //////Colors used by gui elements
  //fg1 = color(0);  //black used for lines on buttons and dropdown
  //fg2 = color(220); //Grey used for some stuff?
  //fg3 = color(255,220,0);  // Yellow used for text and lines on scope
  //bg1 = color(220); //Grey used for button fill and background
  //bg2 = color(0);   //Black used for plot
  //bg3 = color(255); //White used for buttons when mouseover
}

public void draw() {
  clear();//Erase the canvas
  background(frame1.bgfaded);//Set background to greyish green
  
  mouseOverNothing = true;
  for (Element e : frame1.getElements()){  //Draw all of the gui elements
    e.display();
    if (e.mouseOver()) mouseOverNothing = false;
  }
  if (mouseOverNothing) cursor(ARROW);
  
  fill(0);
  textAlign(RIGHT,TOP);
  text("Rsense:",220,12);
  textAlign(LEFT, TOP);
  text("\u03A9",220+rSenseEntry.getWidth(),12);
  
  textAlign(RIGHT,TOP);
  text("Step:",355,12);
  textAlign(LEFT, TOP);
  text("V",355+stepEntry.getWidth(),12);
  
  textAlign(RIGHT,TOP);
  text("Buffer:",500,12);
  
  doSerial();//Send serial message and wait for response
  
  //Write the transfer analytics at the top of scope
  textAlign(LEFT, TOP);
  fill(frame1.fglight);
  text("Gain: " + nf(scope.getSlope(),1,2) + "mS", 100, 55);
  text("Offset: " + nf(scope.getIntercept(),1,4) + "mA", 300, 55);
  text("RMS Noise: " + nf(scope.getRMS(),1,3) + "mA", 500, 55);
}

//Send serial message and wait for response
public void doSerial(){
  if(go){
    try{
    
    if(dacVolts >= 3.3f) {dacVolts=3.3f; dir = -abs(stepVoltage);}
    if(dacVolts <= 0.0f) {dacVolts=0.0f; dir =  abs(stepVoltage);}
    testerPort.clear();  //Empty the buffer just in case it collects some miscellaneous garbage for no reason
    testerPort.write(nf(dacVolts,1,3)+"\n\r");  //Print the desired voltage as a float to the serial port.  I should really convert this to a 12bit value
    
    
    //printArray(byte((str(j)+"\n\r").toCharArray()));
    //print(str(j)+"\n\r");
    //while(testerPort.available()<2);
    
    delay(5);//Give teensy a chance to reply
    
    //while(readin != '\n'){
    //  readin = char(testerPort.read());
    //  in += readin;
    //}
    in = testerPort.readStringUntil('\n');
    //println(in);
    try{
    adcVolts = PApplet.parseFloat(in);
    
    scope.addPoint(dacVolts,adcVolts/rSense*1000.0f);///rsense*1000.0);
    dacVolts += dir;
    }
    catch(Exception e){println("Dropped a packet!");} //If we can't parse a float out of the data, something went wrong
    
    //scope.addPoint(j,k);
    //j+=1;
    //k+=random(-1.0,1.0);
    }
    catch(Exception e){
      println("Error:  Select a valid Serial port");
    }
    while (scope.getSize() >= bufferMax) scope.dropPoint();
  }
  else {
    try{
      dacVolts=0.0f;
      adcVolts=0.0f;
      testerPort.write("0.00\n\r");
    }
    catch(Exception e){
      //println("Error:  Select a valid Serial port");
    }
  }
}

//Called whenever left mouse button is pressed
public void mouseClicked() {
  frame1.handleClick();
  if(millis()-timeOfLastClick < 500) mouseDoubleClicked();
  timeOfLastClick = millis();
}
public void mouseDoubleClicked(){
  frame1.handleDoubleClick();
}
public void mousePressed(){
  previousMouseX = mouseX;
  previousMouseY = mouseY;
  frame1.handlePress();
}
public void mouseDragged(){
  frame1.handleDrag();
}
public void mouseReleased(){
  frame1.handleRelease();
}

public void keyPressed(){
  frame1.handleKeyPress();
  if(key == ' ') playButtonCallback();
}

public void keyReleased(){
  frame1.handleKeyRelease();
}

//Called when refresh button pressed
public void refreshPorts(){
  boolean selectedInPortList = false;
  portsDropdown.clear();
  portList = Serial.list();
  printArray(Serial.list());
  if (portList.length > 0 ){
    for (String p : portList){
      portsDropdown.add(p);
      if (portsDropdown.getSelected().equals(p))
        selectedInPortList = true;
    }
    if (!selectedInPortList)
      portsDropdown.setSelected(0);
  }
  else{
    portsDropdown.setSelected("No UART detected");
  }
}

public void reset(){
  scope.clear();
  dacVolts = 0;
  dir = stepVoltage;
  //go = false;
  //playButton.setTitle("\u25ba");
}

//Called when new port is selected on dropdown
public void changeSerial(){
  try{
    testerPort = new Serial(this,portsDropdown.getSelected(),115200);
  }
  catch(Exception e){;}
}

//Called when button one is pressed.  The serial comms are still gross and unreliable.  need to fix
public void playButtonCallback(){
  refreshPorts();
  if(go)playButton.setTitle("\u25ba");
  else playButton.setTitle("\u25a0");
  go = !go;
}

public void changerSense(){
  if(abs(PApplet.parseFloat(rSenseEntry.getValue()))>0.001f)
    rSense = PApplet.parseFloat(rSenseEntry.getValue());
  rSenseEntry.setValue(nf(rSense,1,2));
}

public void changeBufferMax(){
  if(PApplet.parseInt(bufferEntry.getValue())<=9999 && PApplet.parseInt(bufferEntry.getValue())>0)
    bufferMax = abs(PApplet.parseInt(bufferEntry.getValue()));
  bufferEntry.setValue(nf(bufferMax));
}

public void changeStepVoltage(){
  if(abs(PApplet.parseFloat(stepEntry.getValue()))<3.3f/2 && PApplet.parseFloat(stepEntry.getValue())>0.0f)
    stepVoltage = abs(PApplet.parseFloat(stepEntry.getValue()));
  stepEntry.setValue(nf(stepVoltage,1,2));
}


private void prepareExitHandler() {

Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {

public void run () {

  System.out.println("SHUTDOWN HOOK");

   // application exit code here
   try{
      testerPort = new Serial(papple,portsDropdown.getSelected(),115200);//Reopen serial port because runtime has already closed it
      testerPort.write("0.00\n\r");
      testerPort.stop();  //Close the serial port for real
    }
    catch(Exception e){
      println("Error:  Failed to turn off output on close");
    }

}

}));

}

class Button extends Element{
  //int x,y,w,h,r;
  int r;
  private Runnable runnable;
  public Button(GUI frame, int x, int y, int w, int h){
    super(frame, x,y,w,h,str(random(1.0f)));
    r = 5;
    this.runnable = new Runnable(){public void run(){;}};
  }
  
  public Button(GUI frame, int x, int y, int w, int h, Runnable runnable){
    super(frame, x,y,w,h,str(random(1.0f)));
    r = 5;
    this.runnable = runnable;
    title = "";
  }
  public Button(GUI frame, int x, int y, int w, int h, String title, Runnable runnable){
    super(frame, x,y,w,h,title);
    r = 5;
    this.runnable = runnable;
  }
  
  public void display(){
    noStroke();
    fill(frame.fgfaded);
    if (super.mouseOver()){
      fill(frame.fglight);
      rect(x-2,y-2,w+4,h+4,r);
      cursor(ARROW);
    }
    else rect(x,y,w,h,r);
    fill(frame.fgdark);
    textAlign(CENTER, CENTER);
    text(title,x+w/2,y+h/2-2);//,x+w,y+h+4);
  }
  public void setTitle(String title){
    super.title = title;
  }
  public void onClick(){
    runnable.run();
  }
}
class Dropdown extends Element{
  int temph;
  ArrayList<String> stuff;
  String selected;
  private Runnable runnable;
  public Dropdown(GUI frame, int x, int y, int w, int h, String title){
    super(frame, x,y,w,h,title);
    temph = h;
    stuff = new ArrayList<String>();
    selected = title;
    runnable = new Runnable(){public void run(){;}};
  }
  public Dropdown(GUI frame, int x, int y, int w, int h, String title, Runnable runnable){
    super(frame,x,y,w,h,title);
    temph = h;
    stuff = new ArrayList<String>();
    selected = title;
    this.runnable = runnable;
  }
  public String getSelected(){
    return selected;
  }
  public void setSelected(int n){
    selected = stuff.get(n);
    runnable.run();
    
  }
  public void setSelected(String s){
    selected = s;
    runnable.run();
  }
  public void add(String thing){
    stuff.add(thing);
  }
  public void clear(){
    stuff.clear();
  }
  public ArrayList<String> getStuff(){
    return stuff;
  }
  public void display(){
    if(!this.isFocus)
      temph = h;
    noStroke();
    fill(frame.fgfaded);
    if(this.isFocus || mouseOver()){
      rect(x,y,w,temph,5);
    }
    textAlign(LEFT,CENTER);
    textSize(18);
    if(temph > h){
      for(int i = 0; i < stuff.size(); i++){
        fill(frame.fgfaded);
          if(stuff.get(i).equals(mouseOverWhat())){
            fill(frame.fglight);
            rect(x,y+h*(i+1),w,h,5);
          }
        fill(frame.fgdark);
        text(stuff.get(i),x+10,y+10+h*(i+1));
      }
    
    }
    fill(frame.fgdark);
    textAlign(RIGHT,CENTER);
    text(selected,x+w-36,y+10);
    //if(mouseOver()){
    //  cursor(ARROW);
    //}
    
  }
  public void onClick(){
    if (!(temph>h+2))  temph = h+h*stuff.size();
    else{
      if (!selected.equals(mouseOverWhat())){
        selected = mouseOverWhat();
        runnable.run();
      }
      temph = h; 
    }
  }
  public void defocus(){
    temph = h;
  }
  public boolean mouseOver(){
    return mouseX > x && mouseY > y && mouseX < x + w && mouseY < y + temph;
  }
  public String mouseOverWhat(){
    if (!mouseOver()) return "";
    if (mouseX > x && mouseY > y && mouseX < x + w && mouseY < y + h) return selected;
    return stuff.get(PApplet.parseInt(map(mouseY,y+temph,y+h,stuff.size(),0)));
  } 
}
//A basic gui element with constructor, display(), mouseOver(), and onClick() methods
abstract class Element{
  int x,y,w,h;//,id;
  String title;
  boolean isFocus;
  GUI frame;
  public Element(GUI frame, int x, int y, int w, int h, String title){//, int id){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.title = title;
    this.frame = frame;
    isFocus = false;
    //this.id = id;
  }
  
  public String getTitle(){
    return title;
  }
  
  //execute this if element is focus of gui
  public void onKeyPress(){
    
  }
  public boolean isFocused(){
    return isFocus;
  };
  public void defocus(){
    
  }
  public void onKeyRelease(){
    
  }
  
  //Called in mousePressed() if mouseOver() 
  public void onClick(){
    
  }
  public void onDoubleClick(){
    
  }
  
  public void onPress(){
    
  }
  
  public void onDrag(){
    
  }
  
  public void onRelease(){
    
  }
  
  public void setFocus(boolean tf){
    isFocus = tf;
  }
  //Draw the gui element
  public abstract void display();
  
  //Checks if the mouse is in the rectangular bounds of the gui element
  public boolean mouseOver(){
    return mouseX > x && mouseY > y && mouseX < x + w && mouseY < y + h;
  }
  public boolean mouseOver(int x1, int y1){
    return x1 > x && y1 > y && x1 < x + w && y1 < y + h;
  }
}
class GUI{
  ArrayList<Element> elements;  //Container for gui elements
  String focus;
  int fgdark,fglight,fgfaded,bgdark,bglight,bgfaded;
  
  
  public GUI(){
    elements = new ArrayList<Element>();
    
    //Use default color scheme
    fgdark = color(0,0,0);  //blaque
    fglight = color(255,220,0);  //deep jaundice highlight
    fgfaded = color(255,255,255);  //wight
    bgdark = color(10,40,20);  //Gooseturd dark green slate
    bglight = color(255,255,255);  //Pasty
    bgfaded = color(190,200,195);  //Birdpoop/mildew undersaturated light green
  }
  
  public void add(Element e){
    elements.add(e);
  }
  
  public ArrayList<Element> getElements(){
    return elements;
  }
  
  public void setFocus(String newFocus){
    focus = newFocus;
    focusElement(focus);
  }
  
  public String getFocus(){
    return focus;
  }
  
  public void focusElement(String focus){
    for (int i = 0; i < elements.size(); i++){
      if(elements.get(i).getTitle() == focus)
        elements.get(i).setFocus(true);
      else{
        if (elements.get(i).isFocused())
          elements.get(i).defocus();
        elements.get(i).setFocus(false);
      }
    }
    //println(focus);
  }
  public int getIndex(String element){
    for (int i = 0; i < elements.size(); i++){
      if(elements.get(i).getTitle() == element)
        return i;
    }
    return -1;
  }
  public Element getFocusElement(){
    for (int i = 0; i < elements.size(); i++){
      if(elements.get(i).getTitle() == focus)
        return elements.get(i);
    }
    return null;
  }
  
  public Element getMouseOverElement(){
    for (int i = elements.size()-1; i >= 0; i--){
      if(elements.get(i).mouseOver())
        return elements.get(i);
    }
    return null;
  }
  
  public void handleClick(){
    //println(getMouseOverElement().title);
    if(getMouseOverElement() != null){
      getMouseOverElement().onClick();  //If the mouse is on an element when pressed, call that elements runnable
      return;
    }
    setFocus(null);
  }
  
  public void handleDoubleClick(){
    if(getMouseOverElement() != null){
      getMouseOverElement().onDoubleClick();  //If the mouse is on an element when pressed, call that elements runnable
    }
  }
  public void handlePress(){
    if(getMouseOverElement() != null){
      this.getMouseOverElement().onPress();
      setFocus(getMouseOverElement().getTitle());
    }
  }
  public void handleDrag(){
    if(getMouseOverElement() != null)
    getMouseOverElement().onDrag();
  }
  public void handleRelease(){
    if(getMouseOverElement() != null)
    getMouseOverElement().onRelease();
  }
  
  public void handleKeyPress(){
    //if(key == TAB){
    //  try{
    //  println(getIndex(getFocusElement().getTitle()));
    //  if(getIndex(getFocusElement().getTitle())<elements.size()-1){
    //    focusElement(elements.get(getIndex(getFocusElement().getTitle())+1).getTitle());
    //    println();
    //  }catch(NullPointerException e){
        
    //    focusElement(elements.get(0).getTitle());
    //  }
    //  }else{
    //    focusElement(elements.get(0).getTitle());
    //  }
    //}
    if(getFocusElement() != null)
    getFocusElement().onKeyPress();
  }
  public void handleKeyRelease(){
    if(getFocusElement() != null)
      getFocusElement().onKeyRelease();
  }
}

class Plot extends Element{
  boolean autoscale, showFit, dragging;
  float xmax, xmin, ymax, ymin, winymax, winymin, winxmax, winxmin;
  int yzero, xzero, padLeft, padBot;
  ArrayList<Float> xs,ys;
  ArrayList<Integer> xcoords, ycoords;
  String xlabel, ylabel;
  float xbar,x2bar,ybar,y2bar,intercept,slope,rms,mappedMouseX,mappedMouseY;
  DashedLines dash;
  
  public Plot(GUI frame, int x, int y, int w, int h){
    super(frame, x,y,w,h,str(random(1.0f)));
    xs = new ArrayList<Float>();
    ys = new ArrayList<Float>();
    xcoords = new ArrayList<Integer>();
    ycoords = new ArrayList<Integer>();
    autoscale = true;
    padLeft = 80;
    padBot = 20;
    xlabel = "";
    ylabel = "";
    showFit=true;
    dash = new DashedLines(papple);
    dash.pattern(5, 5);
  }
  
  
  public Plot(GUI frame, int x, int y, int w, int h, String title, String xlabel, String ylabel){
    super(frame, x,y,w,h,title);
    xs = new ArrayList<Float>();
    ys = new ArrayList<Float>();
    xcoords = new ArrayList<Integer>();
    ycoords = new ArrayList<Integer>();
    autoscale = true;
    padLeft = 80;
    padBot = 20;
    this.xlabel = xlabel;
    this.ylabel = ylabel;
    showFit=true;
    dash = new DashedLines(papple);
    dash.pattern(5, 5);
  }
  
  public Plot(GUI frame, int x, int y, int w, int h, float winxmax, float winxmin, float winymax, float winymin){
    super(frame, x,y,w,h,str(random(1.0f)));
    xs = new ArrayList<Float>();
    ys = new ArrayList<Float>();
    xcoords = new ArrayList<Integer>();
    ycoords = new ArrayList<Integer>();
    autoscale = false;
    this.winxmax = winxmax;
    this.winxmin = winxmin;
    this.winymax = winymax;
    this.winymin = winymin;
    padLeft = 100;
    padBot = 20;
    xlabel = "";
    ylabel = "";
    showFit=true;//Whether or not to draw the line of best fit
    dash = new DashedLines(papple);
    dash.pattern(5, 5);
  }
  public Plot(GUI frame, int x, int y, int w, int h, float winxmax, float winxmin, float winymax, float winymin, String title, String xlabel, String ylabel){
    super(frame, x,y,w,h,title);
    xs = new ArrayList<Float>();
    ys = new ArrayList<Float>();
    xcoords = new ArrayList<Integer>();
    ycoords = new ArrayList<Integer>();
    autoscale = false;
    this.winxmax = winxmax;
    this.winxmin = winxmin;
    this.winymax = winymax;
    this.winymin = winymin;
    padLeft = 100;
    padBot = 20;
    this.xlabel = xlabel;
    this.ylabel = ylabel;
    showFit=true;
    dash = new DashedLines(papple);
    dash.pattern(5, 5);
  }
  
  //Update the max, min and coords
  public void update(){
    //Update global extrema
    xmax = max(xs);
    xmin = min(xs);
    ymax = max(ys);
    ymin = min(ys);
    
    if (autoscale){
      if(ymax > Float.MIN_VALUE && ymin < Float.MAX_VALUE){
        winymax = ymax + (ymax-ymin)*.01f;
        winymin = ymin - (ymax-ymin)*.01f;
      }
      if(xmax > Float.MIN_VALUE && xmin < Float.MAX_VALUE){
        winxmax = xmax + (xmax-xmin)*.01f;
        winxmin = xmin - (xmax-xmin)*.01f;
      }
    }
    
    //Adjust window for single point
    if (winymax <= winymin){
      winymax += 1.0f;
      winymin -= 1.0f;
    }
    if (winxmin >= winxmax){
      winxmax += 1.0f;
      winxmin -= 1.0f;
    }
    
    //Y coordinate of x-axis in pixels
    yzero = (int)map(0.0f,winymin,winymax,y+h-padBot,y);
    xzero = (int)map(0.0f,winxmin,winxmax,x+padLeft,x+w);
    
    //Update pixel coordinates of points
    for (int i = 0; i<xs.size(); i++){
      try{
        xcoords.set(i,PApplet.parseInt(map(xs.get(i),winxmin,winxmax,x+padLeft,x+w)));
      }
      catch(IndexOutOfBoundsException e){
        xcoords.add(PApplet.parseInt(map(xs.get(i),winxmin,winxmax,x+padLeft,x+w)));
      }
      try{
        ycoords.set(i,PApplet.parseInt(map(ys.get(i),winymin,winymax,y+h-padBot,y)));
      }
      catch(IndexOutOfBoundsException e){
        ycoords.add(PApplet.parseInt(map(ys.get(i),winymin,winymax,y+h-padBot,y)));
      }
    }
  }
  
  //Draw the frame, axis and points
  public void display(){
    noStroke();
    fill(frame.bgdark);
    rect(x+padLeft,y,w-padLeft,h-padBot,5); // Draw black background
    
    stroke(frame.bgfaded);
    if (winymax < 0.0f) ;//line(x+padLeft,y,x+w,y);          // Draw the x-axis at the top
    else if (winymin > 0.0f) ;//line(x+padLeft,y+h-padBot,x+w,y+h); // or the bottom 
    else line(x+padLeft, yzero, x+w, yzero);               // or somewhere in the middle of the screen

    if (winxmin <0.0f && winxmax>0.0f) line(xzero,y,xzero,y+h-padBot);
    
    //label axes
    //textSize(18);
    fill(frame.fgdark);
    textAlign(RIGHT,TOP);
    text(nf(winymax,1,2),x+padLeft-5,y);
    textAlign(RIGHT,BOTTOM);
    text(nf(winymin,1,2),x+padLeft-5,y+h-padBot);
    textAlign(LEFT,TOP);
    text(nf(winxmin,1,2),x+padLeft,y+h-padBot);
    textAlign(RIGHT,TOP);
    text(nf(winxmax,1,2),x+w,y+h-padBot);
    
    textAlign(CENTER,TOP);
    text(xlabel,x+padLeft/2,y+h-padBot,x+w,y+h-padBot);
    
    textAlign(CENTER,BOTTOM);
    translate(x,y+h-padBot);
    rotate(-PI/2);
    text(ylabel,0,0,h,padLeft-5);
    rotate(PI/2);
    translate(-(x),-(y+h-padBot));
    
    
    //Draw points
    stroke(frame.fglight);
    for (int i = 1; i<xcoords.size(); i++){
      if(true)//xs.get(i)<winxmax && xs.get(i)>winxmin && ys.get(i)<winymax && ys.get(i)>winymin)
        line (xcoords.get(i-1),ycoords.get(i-1),xcoords.get(i),ycoords.get(i));
    }
    if (mouseOver()){
      cursor(CROSS);
      fill(frame.fglight);
      mappedMouseX=map(mouseX,x+padLeft,x+w,winxmin,winxmax);
      mappedMouseY=map(mouseY,y+h-padBot,y,winymin,winymax);
      textAlign(RIGHT,BOTTOM);
      text("("+nf(mappedMouseX,1,3)+", "+nf(mappedMouseY,1,3)+")",x+w-4,y+h-padBot-4);
      if(mouseY < y+h-padBot)
        dash.line(x+padLeft,mouseY,x+w,mouseY);
      if(mouseX > x+padLeft)
        dash.line(mouseX,y,mouseX,y+h-padBot);
    }
    
    if(showFit){
      getIntercept();
      stroke(frame.bgfaded);
      dash.line(x+padLeft,map(winxmin*slope+intercept,winymin,winymax,y+h-padBot,y),x+w,map(winxmax*slope+intercept,winymin,winymax,y+h-padBot,y));
    }
  }
  
  //Add a point (x,y)
  public void addPoint(float x,float y){
    xs.add(new Float(x));
    ys.add(new Float(y));
    update();
  }
  
  //Drop the zero index point
  public void dropPoint(){
    xs.remove(0);
    ys.remove(0);
    xcoords.remove(0);
    ycoords.remove(0);
    update();
  }
  
  public void setAutoscale(boolean autoscale){
    this.autoscale = autoscale;
    update();
  }
  
  public void setWindowFromCoords(int x1, int y1, int x2, int y2){
    autoscale=false;
    if(x1>x2){
      winxmax=map(x1,x+padLeft,x+w,winxmin,winxmax);
      winxmin=map(x2,x+padLeft,x+w,winxmin,winxmax);
    }
    else{
      winxmax=map(x2,x+padLeft,x+w,winxmin,winxmax);
      winxmin=map(x1,x+padLeft,x+w,winxmin,winxmax);
    }
    if(y1<y2){
      winymax=map(y1,y+h-padBot,y,winymin,winymax);
      winymin=map(y2,y+h-padBot,y,winymin,winymax);
    }
    else{
      winymax=map(y2,y+h-padBot,y,winymin,winymax);
      winymin=map(y1,y+h-padBot,y,winymin,winymax);
    }
    update();
  }
  
  public void clear(){
    xs.clear();
    ys.clear();
    xcoords.clear();
    ycoords.clear();
  }
  
  public int getSize(){
    return xs.size();
  }
  
  public float getXbar(){
    int n = xs.size();
    xbar = 0.0f;
    for (float x : xs) xbar+=x;
    xbar /= n;
    return xbar;
  }
  
  public float getYbar(){
    int n = ys.size();
    ybar = 0.0f;
    for(float y : ys) ybar+=y;
    ybar /= n;
    return ybar;
  }
  
  public float getSlope(){
    getXbar();
    getYbar();
    int n = xs.size();
    
    float num=0.0f, den=0.0f;
    for (int i = 0; i < n; i++){
      num+=(xs.get(i)-xbar)*(ys.get(i)-ybar);
      den+=pow((xs.get(i)-xbar),2);
    }
    slope = num/den;
    return slope;
  }
  public float getIntercept(){
    getSlope();
    //println("Slope: " + slope + " Ybar: " + ybar + " Xbar: " + xbar + " slope no intercept: " + ybar/xbar);
    intercept = ybar - xbar*slope;
    return intercept;
  }
  
  public float getRMS(){
    getIntercept();
    int n = xs.size();
    rms = 0.0f;
    for(int i = 0; i < n; i++){
      rms+=pow(slope*xs.get(i)+intercept - ys.get(i),2);
    }
    rms = sqrt(rms/n);
    return rms;
  }
  
  public void onDrag(){
    if(mouseOver(previousMouseX,previousMouseY) && mouseOver()){
      noFill();
      stroke(frame.fglight);
      dash.line(x+padLeft,previousMouseY,x+w,previousMouseY);
      dash.line(previousMouseX,y,previousMouseX,y+h-padBot);
      noStroke();
      fill(255,220,0,10);
      rect(previousMouseX,previousMouseY,mouseX-previousMouseX, mouseY-previousMouseY);
      
    }
  }
  
  public void onRelease(){
  if(mouseOver(previousMouseX,previousMouseY) && mouseOver() && abs(mouseX-previousMouseX) > 5 && abs(mouseY-previousMouseY) > 5)
    setWindowFromCoords(previousMouseX,previousMouseY,mouseX,mouseY);
  }
  
  public void onDoubleClick(){
    setAutoscale(true);
  }
  
  //Calculate max value in float ArrayList
  private float max(ArrayList<Float> nums){
    float currentMax = Float.MIN_VALUE;
    for (float f : nums){
      if(f > currentMax) currentMax = f;
    }
    return currentMax;
  }
  private float min(ArrayList<Float> nums){
    float currentMax = Float.MAX_VALUE;
    for (float f : nums){
      if(f < currentMax) currentMax = f;
    }
    return currentMax;
  }
  
}

class TextEntry extends Element{
  String value;
  int cursorIndex;
  int holdIndex;
  boolean shift;
  Runnable runnable;
  float step;
  public TextEntry(GUI frame, int x, int y, int w, int h, String title, Runnable runnable){
    super(frame, x,y,w,h,title);
    this.runnable = runnable;
    value = "";
    step = 1;
  }
  public void display(){
    if(textWidth(value)>20) w=PApplet.parseInt(textWidth(value))+8;
    if (cursorIndex >= value.length()) cursorIndex = value.length();
    if (holdIndex >= value.length()) holdIndex = value.length();
    fill(frame.fgfaded);
    noStroke();
    if(this.isFocus || mouseOver())
      rect(x,y,w,h,5);
    fill(frame.fgdark);
    textAlign(LEFT,TOP);
    if(mouseOver()){
      cursor(TEXT);
    }
    if(isFocus){
      if(millis()%1000>400){
        stroke(frame.fgdark);
        line(x+4+textWidth(value.substring(0,cursorIndex)),y+4,x+4+textWidth(value.substring(0,cursorIndex)),y+2+18+2);
      }
      fill(frame.fglight);
      noStroke();
      
      if(cursorIndex > holdIndex){
        if (cursorIndex == value.length() && holdIndex == 0) rect(x,y,w,h,5);
        //else if (cursorIndex == value.length())
        //  rect(x+4+textWidth(value.substring(0,holdIndex)),y,w,h,5);
        //else if (holdIndex == 0)
        //  rect(x,y,textWidth(value.substring(holdIndex,cursorIndex)),h,5);
        else
          rect(x+4+textWidth(value.substring(0,holdIndex)),y+3,textWidth(value.substring(holdIndex,cursorIndex)), h-5);
      }
      else if (holdIndex > cursorIndex)
        if (holdIndex == value.length() && cursorIndex == 0) rect(x,y,w,h,5);
        //else if (holdIndex == value.length())
        //  rect(x+4+textWidth(value.substring(0,cursorIndex)),y,w,h,5);
        //else if (cursorIndex == 0)
        //  rect(x,y,textWidth(value.substring(cursorIndex,holdIndex)),h,5);
        else
          rect(x+4+textWidth(value.substring(0,cursorIndex)),y+3,textWidth(value.substring(cursorIndex,holdIndex)), h-5);
      
    }
    fill(frame.fgdark);
    text(value,x+4,y+2);
  }
  public int getWidth(){
    return w;
  }
  public void setValue(String newText){
    value = newText;
  }
  public void defocus(){
    runnable.run();
  }
  public String getValue(){
    return value;
  }
  
  public void onPress(){
    cursorIndex = indexOf(mouseX);
    holdIndex = cursorIndex;
  }
  public void onDrag(){
    cursorIndex = indexOf(mouseX);
  }
  public int indexOf(int xcoord){
    for(int i = value.length();i>=0;i--){
      if (xcoord >= x-3+textWidth(value.substring(0,i))){
        return i;
      }
    }
    return 0;
  }
  public void onDoubleClick(){
    holdIndex = 0;
    cursorIndex = value.length();
  }
  public void setStep(float step){
    this.step=step;
  }
  
  public void onKeyPress(){
    if (key == DELETE){
      if (cursorIndex > holdIndex){
        value = value.substring(0,holdIndex)+value.substring(cursorIndex);
      }
      
      else if (cursorIndex < holdIndex){
        value = value.substring(0,cursorIndex)+value.substring(holdIndex);
      }
      else if (cursorIndex < value.length()){
        value = value.substring(0,cursorIndex)+value.substring(cursorIndex+1);
      }
      cursorIndex = min(cursorIndex,holdIndex);
      holdIndex = cursorIndex;
    }
    else if ((key > 31) && (key != CODED)){
      if (cursorIndex > holdIndex){
        value = value.substring(0,holdIndex)+key+value.substring(cursorIndex);
      }
      
      else if (cursorIndex < holdIndex){
        value = value.substring(0,cursorIndex)+key+value.substring(holdIndex);
      }
      else{
        value = value.substring(0,cursorIndex) + key + value.substring(cursorIndex);
      }
      cursorIndex = min(cursorIndex,holdIndex)+1;
      holdIndex = cursorIndex;
    }
    else if (key == ENTER || key == RETURN){
      runnable.run();
    }
    else if (key == BACKSPACE){
      if (cursorIndex > holdIndex){
        value = value.substring(0,holdIndex)+value.substring(cursorIndex);
      }
      
      else if (cursorIndex < holdIndex){
        value = value.substring(0,cursorIndex)+value.substring(holdIndex);
      }
      
      else if(cursorIndex > 0){
        value = value.substring(0,cursorIndex-1)+value.substring(cursorIndex);
        cursorIndex--;
      }
      cursorIndex = min(holdIndex,cursorIndex);
      holdIndex = cursorIndex;
      
    }
    else if (key == CODED) {
      if (keyCode == LEFT) {
        if(cursorIndex>0)
          cursorIndex--;
        if(!shift){
          cursorIndex = min(cursorIndex,holdIndex);
          holdIndex=cursorIndex;
        }
       
      }
      else if (keyCode == RIGHT){
        if(cursorIndex < value.length())
          cursorIndex++;
        if(!shift){
          cursorIndex = max(cursorIndex,holdIndex);
          holdIndex=cursorIndex;
        }
      }
      else if (keyCode == UP){
        try{
          if (value.indexOf('.')!=-1)
            value = nf(PApplet.parseFloat(value)+step,1,value.length()-1-value.indexOf('.'));
          else
            value = str(PApplet.parseInt(value)+PApplet.parseInt(step));
            
          runnable.run();
        }
        catch(Exception e){
        }
      }
      else if (keyCode == DOWN){
        try{
          if (value.indexOf('.')!=-1)
            value = nf(PApplet.parseFloat(value)-step,1,value.length()-1-value.indexOf('.'));
          else
            value = str(PApplet.parseInt(value)-PApplet.parseInt(step));
          
          runnable.run();
        }
        catch(Exception e){
        }
      }
      else if (keyCode == SHIFT){
        shift = true;
      }
    }
  }
  public void onKeyRelease(){
    if (key == CODED){
      if(keyCode == SHIFT){
        shift = false;
      }
    }
  }
}
  public void settings() {  size(800, 480); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ui" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
